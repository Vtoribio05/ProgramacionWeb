from django.urls import path
from . import views

urlpatterns = [
   
    path('', views.registrar_piloto, name='registrar_piloto'),
    path('pilotos/', views.lista_pilotos, name='pilotos'),
]
