
from django import forms
from .models import Piloto

class PilotoForm(forms.ModelForm):
    class Meta:
        model = Piloto
        fields = ['nombre', 'equipo', 'nacionalidad', 'puntos']
