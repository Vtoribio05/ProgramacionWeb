from django.shortcuts import render , redirect
from django.http import HttpResponse
from django.template import loader
from .models import Piloto

def lista_pilotos(request):
    pilotos = Piloto.objects.all()
    return render(request, 'Lista_pilotos.html', {'pilotos': pilotos})

from .forms import PilotoForm

def registrar_piloto(request):
    if request.method == 'POST':
        form = PilotoForm(request.POST)
        if form.is_valid():
            form.save()  # Guarda el piloto en la base de datos
            return redirect('pilotos')  # Redirige a la lista de pilotos o a donde desees
    else:
        form = PilotoForm()

    return render(request, 'registrar_piloto.html', {'form': form})



